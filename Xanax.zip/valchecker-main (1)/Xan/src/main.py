import asyncio
import ctypes
import json
import os
import random
import shutil  # Add this import statement
import tkinter
import win32api
from tkinter import filedialog
from InquirerPy import inquirer
from InquirerPy.separator import Separator
import colorama

import requests

import checker
from codeparts import checkers, systems, validsort
from codeparts.systems import system
import webbrowser

webbrowser.open('https://discord.gg/vuxmZDxPvA')


check = checkers.checkers()
sys = systems.system()
valid = validsort.validsort()


class program():
    def __init__(self) -> None:
        self.count = 0
        self.checked = 0
        self.version = '3.15.4.2'
        self.riotlimitinarow = 0
        path = os.getcwd()
        self.parentpath = os.path.abspath(os.path.join(path, os.pardir))
        try:
            self.lastver = requests.get(
                'https://api.github.com/repos/lil-jaba/valchecker/releases').json()[0]['tag_name']
        except:
            self.lastver = self.version

    def center_text(self, text):
        columns = shutil.get_terminal_size().columns
        return f"{text:^{columns}}"

    def start(self):
        try:
            print('Enter the key to start:')
            key = input()
            if len(key) != 16:
                print('Invalid key. Exiting...')
                os._exit(0)
            
            print('Key accepted. Starting...')
            print('internet check')
            requests.get('https://github.com')
        except requests.exceptions.ConnectionError:
            print('no internet connection')
            os._exit(0)

        # Clear console
        os.system('cls')
        kernel32 = ctypes.windll.kernel32
        kernel32.SetConsoleMode(kernel32.GetStdHandle(-10), 128)
        codes = vars(colorama.Fore)
        colors = [codes[color] for color in codes if color not in ['BLACK']]
        colored_name = [random.choice(
            colors) + char for char in f'Xan~ax by Xan~Free']
        
        print(self.center_text('Xan~ax by Xan~Free'))
        print(self.center_text(''.join(colored_name))+colorama.Fore.RESET)
        print(self.center_text(f'v{self.version}'))

        self.CheckIfFirstStart()

        if 'beta' in self.version:
            print(self.center_text(
                'You have downloaded the BETA version. It can work unstable and contain some bugs.'))
            print(self.center_text(
                'Visit https://github.com/Xan-Free/uniquechecker/releases/latest to download the latest stable release'))
        elif self.lastver != self.version:
            print(self.center_text(
                f'Next version {self.lastver} is available!'))
            if inquirer.confirm(
                message="Would you like to download it now? (Y/n)",
                default=True,
                qmark=''
            ).execute():
                os.system(f'{self.parentpath}/updater.bat')
                os._exit(0)
        menu_choices = [
            Separator(),
            'Start Checker',
            'Single-Line Checker',
            'Edit Settings',
            'Sort Valid',
            'Test Proxy',
            'Info',
            Separator(),
            'Exit'
        ]
        print(self.center_text('\nhttps://github.com/Xan-Free/uniquechecker\n'))
        print(self.center_text('https://discord.gg/GRzTYuhCgA\n'))
        res = inquirer.select(
            message=self.center_text("\nPlease select an option:"),
            choices=menu_choices,
            default=menu_choices[0],
            pointer='>',
            qmark=''
        ).execute()
        if res == menu_choices[1]:
            self.main()
            input('Finished checking. Press ENTER to exit')
            pr.start()
        elif res == menu_choices[2]:
            slchecker = checker.singlelinechecker()
            slchecker.main()
            pr.start()
        elif res == menu_choices[3]:
            sys.edit_settings()
            pr.start()
        elif res == menu_choices[4]:
            valid.customsort()
            input('Done. Press ENTER to exit')
            pr.start()
        elif res == menu_choices[5]:
            sys.checkproxy()
            pr.start()
        elif res == menu_choices[6]:
            os.system('cls')
            print(self.center_text('''
    Xan~ax v{self.version} by Xan~Free

    

  [~] - Press ENTER to return
            '''))
            input()
            pr.start()
        elif res == menu_choices[8]:
            os._exit(0)

    def get_accounts(self):
        filetypes = (
            ("", ("*.txt", "*.vlchkr")),
            ("All files", "*.*")
        )
        root = tkinter.Tk()
        file = filedialog.askopenfile(parent=root, mode='rb', title='Select a file with combos',
                                      filetypes=filetypes)
        root.destroy()
        os.system('cls')
        if file == None:
            os._exit(0)
        filename = str(file).split("name='")[1].split("'>")[0]
        if (".vlchkr" in filename):
            valkekersource = systems.vlchkrsource(filename)
            return valkekersource
        with open(str(filename), 'r', encoding='UTF-8', errors='replace') as file:
            lines = file.readlines()
            ret = []
            if len(lines) > 100000:
                if inquirer.confirm(
                    message=self.center_text(f"You have more than 100k accounts ({len(lines)}). Do you want to skip the sorting part? (it removes doubles and bad logpasses but can be long)"),
                    default=True,
                    qmark='!',
                    amark='!'
                ).execute():
                    self.count = len(lines)
                    return lines
            for logpass in lines:
                logpass = logpass.strip()
                # remove doubles
                if logpass not in ret and ':' in logpass:
                    self.count += 1
                    ctypes.windll.kernel32.SetConsoleTitleW(
                        f'Xan~ax {self.version} by Xan~Free | Loading Accounts ({self.count})')
                    ret.append(logpass)
            return ret

    def main(self):
        ctypes.windll.kernel32.SetConsoleTitleW(
            f'Xan~ax {self.version} by Xan~Free | Loading Settings')
        print('Loading settings')
        settings = sys.load_settings()        

        ctypes.windll.kernel32.SetConsoleTitleW(
            f'Xan~ax {self.version} by Xan~Free | Loading Proxies')
        print('Loading proxies')
        proxylist = sys.load_proxy()

        if proxylist == None:
            path = os.getcwd()
            file_path = f"{os.path.abspath(os.path.join(path, os.pardir))}\\proxy.txt"

            print('No Proxies Found.')
            response = input('Do you want to scrape proxies? (y/n): ')

            if response.lower() == 'y':
                f = open('system\\settings.json', 'r+')
                data = json.load(f)
                proxyscraper = data['proxyscraper']
                f.close()

                # Scrape proxies
                url = proxyscraper
                proxies = requests.get(url).text.split('\r\n')

                # Save proxies to file
                with open(file_path, 'w') as f:
                    f.write("\n".join(proxies))

                # Print number of proxies saved
                num_proxies = len(proxies)
                print(self.center_text(f'{num_proxies} Proxies saved to "proxy.txt" file.'))
                proxylist = sys.load_proxy()
            else:
                print('Running Proxy Less...')

        ctypes.windll.kernel32.SetConsoleTitleW(
            f'Xan~ax {self.version} by Xan~Free | Loading Accounts')
        print('Loading accounts')
        accounts = self.get_accounts()

        print('Loading assets')
        ctypes.windll.kernel32.SetConsoleTitleW(
            f'Xan~ax {self.version} by Xan~Free | Loading Assets')
        sys.load_assets()

        print('Loading checker')
        ctypes.windll.kernel32.SetConsoleTitleW(
            f'Xan~ax {self.version} by Xan~Free | Loading Checker')
        scheck = checker.simplechecker(settings, proxylist, self.version)

        isvalkekersource = False
        if type(accounts) == systems.vlchkrsource:
            isvalkekersource = True
        asyncio.run(scheck.main(accounts, self.count, isvalkekersource))
        return

    def CheckIfFirstStart(self) -> None:
        with open("system/xd.txt", 'r+') as r:
            if r.read() == '0':
                win32api.MessageBox(None,
                                     """Hello! Looks like it's your first start of Xan~ax.
Although you can find the FAQ and the full guide in my discord, I will specify some things here.


What is a Riot Limit? When you send a lot of auth requests from one IP, riot blocks you for some time.
So that's why you should use proxies for checking. If riot bans your IP, you will not be able to login in their launcher or site for ~30 minutes.

Where can I find proxies? Any website you trust, just search for that in the internet. Or you can ask other people on my discord server.

Where can I find combos? Actually, the answer is the same as with proxies. The internet. But if you want to do combos yourself, you can buy a cheap and effective method on my discord server.


The link to my discord server can be found in the readme section of the github repository or on the Xan~ax title screen.

Good luck!""", "Hello!", 0)
                r.write("1")


pr = program()
if __name__ == '__main__':
    print('Starting')
    pr.start()
